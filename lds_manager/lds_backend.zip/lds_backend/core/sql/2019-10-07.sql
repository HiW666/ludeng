ALTER TABLE `lds`.`user`
ADD COLUMN `create_time` datetime(0) NULL COMMENT '创建时间' AFTER `token`,
ADD COLUMN `update_time` datetime(0) NULL COMMENT '更新时间' AFTER `create_time`;

ALTER TABLE `lds`.`device`
ADD COLUMN `create_time` datetime(0) NULL COMMENT '创建时间' AFTER `area`,
ADD COLUMN `update_time` datetime(0) NULL COMMENT '更新时间' AFTER `create_time`;