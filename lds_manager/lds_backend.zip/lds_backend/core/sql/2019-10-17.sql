ALTER TABLE `lds`.`user`
ADD INDEX `role, area`(`role`, `area`) USING BTREE;