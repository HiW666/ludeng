ALTER TABLE `lds`.`device`
ADD COLUMN `keyword` varchar(255) NULL COMMENT 'query_+code+name,用于模糊查询' AFTER `update_time`,
ADD INDEX `keyword`(`keyword`) USING BTREE;

ALTER TABLE `lds`.`device_message`
ADD COLUMN `keyword` varchar(255) NULL COMMENT 'query_+device_code+device_name,用于模糊查询' AFTER `remark`,
ADD INDEX `keyword`(`keyword`) USING BTREE;

ALTER TABLE `lds`.`user`
MODIFY COLUMN `number` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'UUID' AFTER `id`,
MODIFY COLUMN `account` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户账号' AFTER `number`,
MODIFY COLUMN `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码' AFTER `account`,
MODIFY COLUMN `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '名称' AFTER `password`,
MODIFY COLUMN `role` int(1) NOT NULL COMMENT '角色：0、设备查看员，1、设备管理员，2、系统管理员，' AFTER `name`;

ALTER TABLE `lds`.`device`
MODIFY COLUMN `number` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'UUID' AFTER `id`,
MODIFY COLUMN `code` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '设备编号' AFTER `number`,
MODIFY COLUMN `status` int(1) NOT NULL COMMENT '设备状态：0、正常，1、跳闸，2、离线，' AFTER `name`,
MODIFY COLUMN `create_time` datetime(0) NULL COMMENT '创建时间' AFTER `area`,
MODIFY COLUMN `keyword` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'query_+code+name,用于模糊查询' AFTER `update_time`;

ALTER TABLE `lds`.`device_message`
MODIFY COLUMN `number` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'UUID' AFTER `id`,
MODIFY COLUMN `device_number` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '设备number' AFTER `number`,
MODIFY COLUMN `device_code` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '设备唯一编码' AFTER `device_number`,
MODIFY COLUMN `type` int(1) NOT NULL COMMENT '故障类型：1、异常跳闸，2、通信断开，' AFTER `area`,
MODIFY COLUMN `status` int(1) NOT NULL COMMENT '故障处理状态：0、未处理，1、处理中，2、已处理，' AFTER `push_state`,
MODIFY COLUMN `keyword` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'device_code+device_name,用于模糊查询' AFTER `remark`;