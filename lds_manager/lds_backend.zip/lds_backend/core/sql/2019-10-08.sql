ALTER TABLE `lds`.`device_message`
ADD INDEX `device_number, type, status`(`device_number`, `type`, `status`) USING BTREE;

ALTER TABLE `lds`.`device_message`
ADD COLUMN `device_code` varchar(25) NULL COMMENT '设备唯一编码' AFTER `device_number`,
ADD COLUMN `device_name` varchar(50) NULL COMMENT '设备名称' AFTER `device_code`;

ALTER TABLE `lds`.`device_message`
MODIFY COLUMN `type` int(1) NULL DEFAULT NULL COMMENT '故障类型：1、异常跳闸，2、通信断开，' AFTER `area`;