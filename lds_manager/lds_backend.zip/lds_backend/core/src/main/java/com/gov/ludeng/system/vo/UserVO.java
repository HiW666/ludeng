package com.gov.ludeng.system.vo;

import com.gov.ludeng.system.entity.User;

import java.util.List;

public class UserVO extends User {

    private static final long serialVersionUID = -2831489217046758000L;

    private List<Integer> roles;

    public List<Integer> getRoles() {
        return roles;
    }

    public void setRoles(List<Integer> roles) {
        this.roles = roles;
    }
}
