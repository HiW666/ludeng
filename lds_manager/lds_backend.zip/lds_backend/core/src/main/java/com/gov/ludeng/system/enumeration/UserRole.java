package com.gov.ludeng.system.enumeration;


import com.gov.ludeng.common.utils.BeanMapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 设备状态：0、正常，1、跳闸，2、离线，
 */
public enum UserRole {


    TYPE_0(0, "设备查看员"), TYPE_1(1, "设备管理员"), TYPE_2(2, "系统管理员");

    private Integer code;
    private String name;

    UserRole(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static List<Map<String, Object>> getElements() {
        UserRole[] values = UserRole.values();
        List<Map<String, Object>> elements = new ArrayList<Map<String, Object>>(values.length);
        for (UserRole type : values) {
            try {
                elements.add(BeanMapUtils.toMap(type));
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        }

        return elements;
    }

    public static Integer getCodeByName(String name) {
        if (StringUtils.isEmpty(name)) return null;
        UserRole[] values = UserRole.values();
        for (UserRole type : values) {
            if (type.getName().equals(name)) {
                return type.getCode();
            }
        }
        return null;
    }

    public static String getNameByCode(Integer code) {
        if (code == null) {
            return "";
        }
        UserRole[] values = UserRole.values();
        for (UserRole type : values) {
            if (type.getCode().equals(code)) {
                return type.getName();
            }
        }
        return "";
    }
}
