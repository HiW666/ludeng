package com.gov.ludeng.system.controller;

import com.gov.ludeng.common.base.entity.JsonResult;
import com.gov.ludeng.system.enumeration.DeviceMessageStatus;
import com.gov.ludeng.system.enumeration.DeviceMessageType;
import com.gov.ludeng.system.enumeration.DeviceStatus;
import com.gov.ludeng.system.enumeration.UserRole;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/common")
public class CommonController {

    @ResponseBody
    @RequestMapping(value = "dictionary", method = RequestMethod.POST)
    public JsonResult dictionary() {
        JsonResult result = new JsonResult();
        Map<String,Object> map = new HashMap<>();
        map.put("DeviceMessageStatus", DeviceMessageStatus.getElements());
        map.put("DeviceMessageType", DeviceMessageType.getElements());
        map.put("DeviceStatus", DeviceStatus.getElements());
        map.put("UserRole", UserRole.getElements());
        result.setData(map);
        return result;
    }
}
