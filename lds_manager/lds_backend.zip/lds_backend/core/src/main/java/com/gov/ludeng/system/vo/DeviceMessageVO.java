package com.gov.ludeng.system.vo;

import com.gov.ludeng.system.entity.DeviceMessage;

public class DeviceMessageVO extends DeviceMessage {

    private static final long serialVersionUID = 8065967089569932541L;

    private String devStatus;

    private String dealName;

    public String getDealName() {
        return dealName;
    }

    public void setDealName(String dealName) {
        this.dealName = dealName;
    }

    public String getDevStatus() {
        return devStatus;
    }

    public void setDevStatus(String devStatus) {
        this.devStatus = devStatus;
    }
}
