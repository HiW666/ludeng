package com.gov.ludeng.system.controller;

import com.gov.ludeng.common.base.entity.*;
import com.gov.ludeng.common.base.exception.BaseException;
import com.gov.ludeng.system.service.UserService;
import com.gov.ludeng.system.vo.UserVO;
import com.gov.ludeng.system.vo.valid.LoginValid;
import com.gov.ludeng.system.vo.valid.UserValid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private Test test;
    
    @ResponseBody
    @RequestMapping(value="test")
    public String getTest() {
    	return test.getStr() + test.getOne();
    }

    @ResponseBody
    @RequestMapping(value = "info", method = RequestMethod.POST)
    public JsonResult getUser(String token) {
        JsonResult result = new JsonResult();
        String number = token.substring(0, token.indexOf("-"));
        result.setData(userService.getUser(number));
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "login", method = RequestMethod.POST)
    public JsonResult login(@Valid LoginValid loginValid) {
        JsonResult result = new JsonResult();
        result.setData(userService.login(loginValid.getAccount(), loginValid.getPassword()));
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "list", method = RequestMethod.POST)
    public JsonResult getPageInfo(UserVO user, Pagination pagination) {
        JsonResult result = new JsonResult();
        result.setData(userService.getList(user, pagination));
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "add", method = RequestMethod.POST)
    public JsonResult add(@Validated({AddGroup.class}) UserValid valid) {
        JsonResult result = new JsonResult();
        userService.add(valid);
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public JsonResult update(@Validated({UpdateGroup.class}) UserValid valid, Integer userId) {
        if (userId == null) {
            throw new BaseException("用户ID不能为空");
        }
        JsonResult result = new JsonResult();
        userService.update(valid, userId);
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "delete", method = RequestMethod.POST)
    public JsonResult delete(Integer userId) {
        if (userId == null) {
            throw new BaseException("用户ID不能为空");
        }
        JsonResult result = new JsonResult();
        userService.deleteById(userId);
        return result;
    }
}