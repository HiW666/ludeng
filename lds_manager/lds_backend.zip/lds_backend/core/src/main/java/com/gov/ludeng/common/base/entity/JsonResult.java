package com.gov.ludeng.common.base.entity;

/**
 *
 * JSON模型
 *
 * 用户后台向前台返回的JSON对象
 *
 *
 */
public class JsonResult implements java.io.Serializable {

	private static final long serialVersionUID = -4652918180001959792L;

	private String msg = "";

	private int code = 0;

	private Object data = null;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public void setCode(int code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public JsonResult(){
		this.data = null;
		this.code = 0;
		this.msg = "";
	}

	public JsonResult(Object data){
		this.data = data;
		this.code = 0;
		this.msg = "";
	}

	public JsonResult(Object data, int code, String msg){
		this.data = data;
		this.code = code;
		this.msg = msg;
	}
}
