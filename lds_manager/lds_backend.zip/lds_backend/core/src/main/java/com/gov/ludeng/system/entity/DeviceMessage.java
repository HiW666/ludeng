package com.gov.ludeng.system.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Table(name = "device_message")
public class DeviceMessage implements Serializable {
	
	private static final long serialVersionUID = 7326707134512374083L;


    /**
     * 
     */
    @Column(name = "id",table = "device_message",columnDefinition = "")
    @Id
    private Integer id;

    /**
     * UUID
     */
    @Column(name = "number",table = "device_message",columnDefinition = "UUID")
    private String number;

    /**
     * 设备number
     */
    @Column(name = "device_number",table = "device_message",columnDefinition = "设备number")
    private String deviceNumber;

    /**
     * 设备唯一编码
     */
    @Column(name = "device_code",table = "device_message",columnDefinition = "设备唯一编码")
    private String deviceCode;

    /**
     * 设备名称
     */
    @Column(name = "device_name",table = "device_message",columnDefinition = "设备名称")
    private String deviceName;

    /**
     * 区域(预留)
     */
    @Column(name = "area",table = "device_message",columnDefinition = "区域(预留)")
    private String area;

    /**
     * 故障类型：1、异常跳闸，2、通信断开，
     */
    @Column(name = "type",table = "device_message",columnDefinition = "故障类型：1、异常跳闸，2、通信断开，")
    private Integer type;

    /**
     * 消息创建时间
     */
    @Column(name = "create_time",table = "device_message",columnDefinition = "消息创建时间")
    
    private Date createTime;

    /**
     * 故障二次推送时间
     */
    @Column(name = "second_push_time",table = "device_message",columnDefinition = "故障二次推送时间")
    private Date secondPushTime;

    /**
     * 是否已二次推送
     */
    @Column(name = "push_state",table = "device_message",columnDefinition = "是否已二次推送")
    private Boolean pushState;

    /**
     * 故障处理状态：0、未处理，1、处理中，2、已处理，
     */
    @Column(name = "status",table = "device_message",columnDefinition = "故障处理状态：0、未处理，1、处理中，2、已处理，")
    private Integer status;

    /**
     * 故障处理日期
     */
    @Column(name = "deal_time",table = "device_message",columnDefinition = "故障处理日期")
    private Date dealTime;

    /**
     * 处理用户number
     */
    @Column(name = "deal_user_number",table = "device_message",columnDefinition = "处理用户number")
    private String dealUserNumber;

    /**
     * 故障处理描述
     */
    @Column(name = "remark",table = "device_message",columnDefinition = "故障处理描述")
    private String remark;

    /**
     * device_code+device_name,用于模糊查询
     */
    @Column(name = "keyword",table = "device_message",columnDefinition = "device_code+device_name,用于模糊查询")
    @JsonIgnore
    private String keyword;

    /**
     * 
     * @return id 
     */
    public Integer getId() {
        return id;
    }

    /**
     * 
     * @param id 
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * UUID
     * @return number UUID
     */
    public String getNumber() {
        return number;
    }

    /**
     * UUID
     * @param number UUID
     */
    public void setNumber(String number) {
        this.number = number;
    }

    /**
     * 设备number
     * @return device_number 设备number
     */
    public String getDeviceNumber() {
        return deviceNumber;
    }

    /**
     * 设备number
     * @param deviceNumber 设备number
     */
    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    /**
     * 设备唯一编码
     * @return device_code 设备唯一编码
     */
    public String getDeviceCode() {
        return deviceCode;
    }

    /**
     * 设备唯一编码
     * @param deviceCode 设备唯一编码
     */
    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    /**
     * 设备名称
     * @return device_name 设备名称
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * 设备名称
     * @param deviceName 设备名称
     */
    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    /**
     * 区域(预留)
     * @return area 区域(预留)
     */
    public String getArea() {
        return area;
    }

    /**
     * 区域(预留)
     * @param area 区域(预留)
     */
    public void setArea(String area) {
        this.area = area;
    }

    /**
     * 故障类型：1、异常跳闸，2、通信断开，
     * @return type 故障类型：1、异常跳闸，2、通信断开，
     */
    public Integer getType() {
        return type;
    }

    /**
     * 故障类型：1、异常跳闸，2、通信断开，
     * @param type 故障类型：1、异常跳闸，2、通信断开，
     */
    public void setType(Integer type) {
        this.type = type;
    }

    /**
     * 消息创建时间
     * @return create_time 消息创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 消息创建时间
     * @param createTime 消息创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 故障二次推送时间
     * @return second_push_time 故障二次推送时间
     */
    public Date getSecondPushTime() {
        return secondPushTime;
    }

    /**
     * 故障二次推送时间
     * @param secondPushTime 故障二次推送时间
     */
    public void setSecondPushTime(Date secondPushTime) {
        this.secondPushTime = secondPushTime;
    }

    /**
     * 是否已二次推送
     * @return push_state 是否已二次推送
     */
    public Boolean getPushState() {
        return pushState;
    }

    /**
     * 是否已二次推送
     * @param pushState 是否已二次推送
     */
    public void setPushState(Boolean pushState) {
        this.pushState = pushState;
    }

    /**
     * 故障处理状态：0、未处理，1、处理中，2、已处理，
     * @return status 故障处理状态：0、未处理，1、处理中，2、已处理，
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 故障处理状态：0、未处理，1、处理中，2、已处理，
     * @param status 故障处理状态：0、未处理，1、处理中，2、已处理，
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 故障处理日期
     * @return deal_time 故障处理日期
     */
    public Date getDealTime() {
        return dealTime;
    }

    /**
     * 故障处理日期
     * @param dealTime 故障处理日期
     */
    public void setDealTime(Date dealTime) {
        this.dealTime = dealTime;
    }

    /**
     * 处理用户number
     * @return deal_user_number 处理用户number
     */
    public String getDealUserNumber() {
        return dealUserNumber;
    }

    /**
     * 处理用户number
     * @param dealUserNumber 处理用户number
     */
    public void setDealUserNumber(String dealUserNumber) {
        this.dealUserNumber = dealUserNumber;
    }

    /**
     * 故障处理描述
     * @return remark 故障处理描述
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 故障处理描述
     * @param remark 故障处理描述
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * device_code+device_name,用于模糊查询
     * @return keyword device_code+device_name,用于模糊查询
     */
    public String getKeyword() {
        return keyword;
    }

    /**
     * device_code+device_name,用于模糊查询
     * @param keyword device_code+device_name,用于模糊查询
     */
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
}