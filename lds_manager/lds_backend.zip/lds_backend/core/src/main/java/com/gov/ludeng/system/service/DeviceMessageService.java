package com.gov.ludeng.system.service;


import com.github.pagehelper.PageInfo;
import com.gov.ludeng.common.base.entity.Pagination;
import com.gov.ludeng.common.base.service.BaseService;
import com.gov.ludeng.system.entity.DeviceMessage;
import com.gov.ludeng.system.enumeration.DeviceMessageType;
import com.gov.ludeng.system.vo.DeviceMessageVO;
import com.gov.ludeng.system.vo.DeviceVO;

import java.util.List;


public interface DeviceMessageService extends BaseService<DeviceMessage, Integer> {

    PageInfo getList(DeviceMessageVO deviceMessage, Pagination pagination);

    void add(DeviceVO device, DeviceMessageType type);

    void handle(List<Integer> msgIds, String userNumber, Integer status, String remark);

    void updateStatusByDeviceNumber(String deviceNumber, Integer type);

    List<DeviceMessageVO> getNoDealMessage(String deviceNumber, Integer type);

    List<DeviceMessageVO> getSecondPushList();
}
