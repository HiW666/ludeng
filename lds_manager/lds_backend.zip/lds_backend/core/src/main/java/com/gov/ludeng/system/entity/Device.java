package com.gov.ludeng.system.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Table(name = "device")
public class Device implements Serializable {

    private static final long serialVersionUID = -5036014299928466137L;


    /**
     *
     */
    @Column(name = "id", table = "device", columnDefinition = "")
    @Id
    private Integer id;

    /**
     * UUID
     */
    @Column(name = "number", table = "device", columnDefinition = "UUID")
    private String number;

    /**
     * 设备编号
     */
    @Column(name = "code", table = "device", columnDefinition = "设备编号")
    private String code;

    /**
     * 设备名称
     */
    @Column(name = "name", table = "device", columnDefinition = "设备名称")
    private String name;

    /**
     * 设备状态：0、正常，1、跳闸，2、离线，
     */
    @Column(name = "status", table = "device", columnDefinition = "设备状态：0、正常，1、跳闸，2、离线，")
    private Integer status;

    /**
     * 最后一次心跳时间
     */
    @Column(name = "last_heart_beat_time", table = "device", columnDefinition = "最后一次心跳时间")
    private Date lastHeartBeatTime;

    /**
     * 设备复位时间
     */
    @Column(name = "reset_time", table = "device", columnDefinition = "设备复位时间")
    private Integer resetTime;

    /**
     * 区域(预留)
     */
    @Column(name = "area", table = "device", columnDefinition = "区域(预留)")
    private String area;

    /**
     * 创建时间
     */
    @Column(name = "create_time", table = "device", columnDefinition = "创建时间")
    private Date createTime;

    /**
     * 更新时间
     */
    @Column(name = "update_time", table = "device", columnDefinition = "更新时间")
    private Date updateTime;

    /**
     * query_+code+name,用于模糊查询
     */
    @Column(name = "keyword",table = "device",columnDefinition = "query_+code+name,用于模糊查询")
    @JsonIgnore
    private String keyword;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * UUID
     *
     * @return number UUID
     */
    public String getNumber() {
        return number;
    }

    /**
     * UUID
     *
     * @param number UUID
     */
    public void setNumber(String number) {
        this.number = number;
    }

    /**
     * 设备编号
     *
     * @return code 设备编号
     */
    public String getCode() {
        return code;
    }

    /**
     * 设备编号
     *
     * @param code 设备编号
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 设备名称
     *
     * @return name 设备名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设备名称
     *
     * @param name 设备名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 设备状态：0、正常，1、跳闸，2、离线，
     *
     * @return status 设备状态：0、正常，1、跳闸，2、离线，
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设备状态：0、正常，1、跳闸，2、离线，
     *
     * @param status 设备状态：0、正常，1、跳闸，2、离线，
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 最后一次心跳时间
     *
     * @return last_heart_beat_time 最后一次心跳时间
     */
    public Date getLastHeartBeatTime() {
        return lastHeartBeatTime;
    }

    /**
     * 最后一次心跳时间
     *
     * @param lastHeartBeatTime 最后一次心跳时间
     */
    public void setLastHeartBeatTime(Date lastHeartBeatTime) {
        this.lastHeartBeatTime = lastHeartBeatTime;
    }

    /**
     * 设备复位时间
     *
     * @return reset_time 设备复位时间
     */
    public Integer getResetTime() {
        return resetTime;
    }

    /**
     * 设备复位时间
     *
     * @param resetTime 设备复位时间
     */
    public void setResetTime(Integer resetTime) {
        this.resetTime = resetTime;
    }

    /**
     * 区域(预留)
     *
     * @return area 区域(预留)
     */
    public String getArea() {
        return area;
    }

    /**
     * 区域(预留)
     *
     * @param area 区域(预留)
     */
    public void setArea(String area) {
        this.area = area;
    }

    /**
     * 创建时间
     *
     * @return createTime 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 更新时间
     *
     * @return updateTime 更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * query_+code+name,用于模糊查询
     * @return keyword query_+code+name,用于模糊查询
     */
    public String getKeyword() {
        return keyword;
    }

    /**
     * query_+code+name,用于模糊查询
     * @param keyword query_+code+name,用于模糊查询
     */
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
}