package com.gov.ludeng.common.config;

import com.alibaba.fastjson.JSON;
import com.gov.ludeng.common.base.entity.JsonResult;
import com.gov.ludeng.common.base.exception.BaseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 捕获controller的异常
 */
@RestControllerAdvice
public class ControllerExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(ControllerExceptionHandler.class);


    @ExceptionHandler(Exception.class)
    @ResponseBody
    public JsonResult handleControllerException(HttpServletRequest req, Exception ex) {
        JsonResult json;
//        RequestUtil requestUtil = new RequestUtil();
        logger.error(JSON.toJSONString(req.getParameterMap()));
        // String jsonText = requestUtil.getBodyString(req);
        //System.out.println(jsonText);
        if (ex instanceof BindException) {
            BindException be = (BindException) ex;
            List<ObjectError> errors = be.getAllErrors();
            if (errors != null && errors.size() > 0) {
                json = new JsonResult(null, -1, errors.get(0).getDefaultMessage());
            } else {
                json = new JsonResult(null, -1, be.getMessage());
            }
        /*    MethodArgumentNotValidException c = (MethodArgumentNotValidException) ex;
            List<ObjectError> errors = c.getBindingResult().getAllErrors();
            StringBuffer errorMsg = new StringBuffer();
            errors.stream().forEach(x -> errorMsg.append(x.getDefaultMessage()).append(";"));
            if (errorMsg.length() > 1) {
                errorMsg.deleteCharAt(errorMsg.length() - 1);
            }*/
        } else if (ex instanceof BaseException) {
            BaseException udfException = (BaseException) ex;
            json = new JsonResult(null, udfException.getErrorCode(), udfException.getMessage());

        } else {
            json = new JsonResult(null, 1000, ex.getMessage());
        }

        if (json.getMsg() != null && json.getMsg().length() > 100) {
            json.setMsg(json.getMsg().substring(0, 100));
        }
        logger.error("url>>>: " + req.getRequestURI());
        logger.error(ex.getMessage(), ex);
        return json;
    }

}
