package com.gov.ludeng.system.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Table(name = "user")
public class User implements Serializable {

	private static final long serialVersionUID = -1938774961756228563L;


    /**
     *
     */
    @Column(name = "id",table = "user",columnDefinition = "")
    @Id
    private Integer id;

    /**
     * UUID
     */
    @Column(name = "number",table = "user",columnDefinition = "UUID")
    private String number;

    /**
     * 用户账号
     */
    @Column(name = "account",table = "user",columnDefinition = "用户账号")
    private String account;

    /**
     * 密码
     */
    @JsonIgnore
    @Column(name = "password",table = "user",columnDefinition = "密码")
    private String password;

    /**
     * 名称
     */
    @Column(name = "name",table = "user",columnDefinition = "名称")
    private String name;

    /**
     * 角色
     */
    @Column(name = "role",table = "user",columnDefinition = "角色")
    private Integer role;

    /**
     * 区域(预留)
     */
    @Column(name = "area",table = "user",columnDefinition = "区域(预留)")
    private String area;

    /**
     *
     */
    @Column(name = "token",table = "user",columnDefinition = "")
    private String token;

    /**
     * 创建时间
     */
    @Column(name = "create_time",table = "user",columnDefinition = "创建时间")
    private Date createTime;

    /**
     * 更新时间
     */
    @Column(name = "update_time",table = "user",columnDefinition = "更新时间")
    private Date updateTime;


    /**
     *
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * UUID
     * @return number UUID
     */
    public String getNumber() {
        return number;
    }

    /**
     * UUID
     * @param number UUID
     */
    public void setNumber(String number) {
        this.number = number;
    }

    /**
     * 用户账号
     * @return account 用户账号
     */
    public String getAccount() {
        return account;
    }

    /**
     * 用户账号
     * @param account 用户账号
     */
    public void setAccount(String account) {
        this.account = account;
    }

    /**
     * 密码
     * @return password 密码
     */
    public String getPassword() {
        return password;
    }

    /**
     * 密码
     * @param password 密码
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * 名称
     * @return name 名称
     */
    public String getName() {
        return name;
    }

    /**
     * 名称
     * @param name 名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 角色
     * @return role 角色
     */
    public Integer getRole() {
        return role;
    }

    /**
     * 角色
     * @param role 角色
     */
    public void setRole(Integer role) {
        this.role = role;
    }

    /**
     * 区域(预留)
     * @return area 区域(预留)
     */
    public String getArea() {
        return area;
    }

    /**
     * 区域(预留)
     * @param area 区域(预留)
     */
    public void setArea(String area) {
        this.area = area;
    }

    /**
     *
     * @return token
     */
    public String getToken() {
        return token;
    }

    /**
     *
     * @param token
     */
    public void setToken(String token) {
        this.token = token;
    }

    /**
     * 创建时间
     * @return create_time 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 更新时间
     * @return update_time 更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 更新时间
     * @param updateTime 更新时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}