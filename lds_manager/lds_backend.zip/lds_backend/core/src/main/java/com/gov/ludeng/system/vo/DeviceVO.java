package com.gov.ludeng.system.vo;

import com.gov.ludeng.system.entity.Device;

public class DeviceVO extends Device {

    private static final long serialVersionUID = 2315335137534009463L;

}
