package com.gov.ludeng.scheduler;

import com.gov.ludeng.JPush.entity.PushResultInfo;
import com.gov.ludeng.JPush.service.JPushService;
import com.gov.ludeng.common.utils.DateUtil;
import com.gov.ludeng.system.enumeration.DeviceMessageType;
import com.gov.ludeng.system.enumeration.PushType;
import com.gov.ludeng.system.service.DeviceMessageService;
import com.gov.ludeng.system.service.DeviceService;
import com.gov.ludeng.system.service.UserService;
import com.gov.ludeng.system.vo.DeviceMessageVO;
import com.gov.ludeng.system.vo.DeviceVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Component
@Configurable
@EnableScheduling
@EnableAsync
public class TaskJob {

    private static final Logger logger = LoggerFactory.getLogger(TaskJob.class);

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private DeviceMessageService deviceMessageService;

    @Autowired
    private UserService userService;

    @Autowired
    private JPushService jPushService;

    /**
     * 心跳检测任务，5分钟执行
     */
    @Scheduled(cron = "0 0/5 * * * ?")
    public void executeDisconnectJob() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
        logger.info("时间:" + format.format(Calendar.getInstance().getTime()) + " 开始心跳检测.....");

        // TODO 先查找最后心跳时间在10分钟前的设备
        int time = -1 * 10 * 60;
        Date date = DateUtil.getCurrentAfterSeconds(time);
        List<DeviceVO> list = deviceService.getDisconnectDevice(date);
        if (list != null && list.size() > 0) {
            for (DeviceVO d : list) {
                deviceMessageService.add(d, DeviceMessageType.DISCONNECT);
            }
        }
        logger.info("时间:" + format.format(Calendar.getInstance().getTime()) + " 心跳检测结束");
    }

    /**
     * 跳匝二次推送任务，5分钟执行
     */
    @Scheduled(cron = "0 0/5 * * * ?")
    public void executeBreakJob() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
        logger.info("时间:" + format.format(Calendar.getInstance().getTime()) + " 开始二次推送检测.....");

        // TODO 先查找故障二次推送超时的设备
        List<DeviceMessageVO> list = deviceMessageService.getSecondPushList();
        if (list != null && list.size() > 0) {
            List<String> userList = userService.getUserList(null);
            for (DeviceMessageVO dm : list) {
                PushResultInfo result = jPushService.doPushMessage(dm.getDeviceCode(), PushType.BREAK, userList);
                // 推送成功，更新推送状态
                if (result.getStatusCode() == 0) {
                    DeviceMessageVO update = new DeviceMessageVO();
                    update.setId(dm.getId());
                    update.setPushState(true);
                    deviceMessageService.updateSelectiveById(update);
                }
            }
        }
        logger.info("时间:" + format.format(Calendar.getInstance().getTime()) + " 二次推送结束");
    }
}
