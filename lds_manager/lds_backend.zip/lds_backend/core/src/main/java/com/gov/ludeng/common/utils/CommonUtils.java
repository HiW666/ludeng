package com.gov.ludeng.common.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

public class CommonUtils {

    public static void main(String[] args) {
        System.out.println(getRandomKey());
    }

    public static String getRandomKey(){
        String key = UUID.randomUUID().toString().replace("-","");
        return key;
    }

    public static Integer getTimeStamp(){
        return (int)(System.currentTimeMillis()/1000);
    }


    public static boolean isEmpty(Object str) {
        if(str==null || str.toString().trim().length()==0){
            return true;
        }
        return false;
    }

    /**
     * 正则表达式：验证手机号 可带区号 + 1-4位
     */
    public static final String REGEX_MOBILE = "^(\\+[0-9]{1,4})?((13[0-9])|(14[0-9])|(15[^4,\\D])|(16[0-9])|(17[0-9])|(18[0-9])|(19[0-9]))\\d{8}$";

    /**
     * 校验手机号
     */
    public static boolean isMobile(String mobile) {
        return matches(REGEX_MOBILE, mobile);
    }
    public static boolean matches(String regex, String str) {
        if (isEmpty(str))
            return false;
        return Pattern.matches(regex, str);
    }


    /**
     * 相同对象进行copy,空值过滤
     *
     * @param origin
     * @param destination
     */
    public synchronized static <T> void mergeObject(T origin, T destination) {
        mergeObject(origin, destination, false);
    }

    public synchronized static <T> void mergeObject(T origin, T destination, boolean isNull, String... filters) {
        if (origin == null || destination == null) {
            return;
        }
        if (!origin.getClass().equals(destination.getClass())) {
            return;
        }

        Field[] fields = origin.getClass().getDeclaredFields();
        List<String> filterList = filters == null ? new ArrayList<String>() : Arrays.asList(filters);
        for (int i = 0; i < fields.length; i++) {
            try {
                fields[i].setAccessible(true);
                Object value = fields[i].get(origin);
                boolean flag = filterList.contains(fields[i].getName());
                if (flag || ((isNull && value != null) || !CommonUtils.isEmpty(value))) {
                    fields[i].set(destination, value);
                }
                fields[i].setAccessible(false);
            } catch (Exception e) {
            }
        }
    }


    // 把stacktrace输出为字符串
    public static String getStackTrace(Throwable throwable) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw, true);
        throwable.printStackTrace(pw);
        return sw.getBuffer().toString();
    }
}
