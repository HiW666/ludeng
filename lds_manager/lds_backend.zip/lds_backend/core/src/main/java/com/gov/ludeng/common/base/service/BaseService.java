package com.gov.ludeng.common.base.service;

import com.github.pagehelper.PageInfo;
import com.gov.ludeng.common.base.entity.Pagination;


import java.io.Serializable;
import java.util.List;

public interface BaseService<M, ID extends Serializable> extends Serializable {

    public <P> PageInfo<P>  getPageInfo(Pagination pagination, Class<P> pClass) ;

    public <P> List<P>  getAllInfo(P p) ;

    public M selectOne(M entity);


    public M selectById(ID id);


    public List<M> selectList(M entity);


    public List<M> selectListAll();


    public Long selectCount(M entity);


    public M insert(M entity);


    public M insertSelective(M entity);


    public void deleteById(ID id);


    public void updateById(M entity);


    public void updateSelectiveById(M entity);

    public List<M> selectByExample(Object example);

    public int selectCountByExample(Object example);

}
