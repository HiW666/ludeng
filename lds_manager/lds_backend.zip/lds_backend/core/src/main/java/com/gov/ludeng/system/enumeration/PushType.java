package com.gov.ludeng.system.enumeration;

import com.gov.ludeng.common.utils.BeanMapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public enum PushType {


    PRE_BREAK("检修预警", "设备异常跳匝，请注意"),
    BREAK("抢修警报", "设备跳匝超时没有自动恢复，请安排人员处理"),
    DISCONNECT("通信断开", "有设备通信断开，请注意")
    ;

    private String code;
    private String name;

    PushType(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static List<Map<String, Object>> getElements() {
        PushType[] values = PushType.values();
        List<Map<String, Object>> elements = new ArrayList<Map<String, Object>>(values.length);
        for (PushType type : values) {
            try {
                elements.add(BeanMapUtils.toMap(type));
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        }

        return elements;
    }

    public static String getCodeByName(String name) {
        if (StringUtils.isEmpty(name)) return null;
        PushType[] values = PushType.values();
        for (PushType type : values) {
            if (type.getName().equals(name)) {
                return type.getCode();
            }
        }
        return null;
    }

    public static String getNameByCode(String code) {
        if (code == null) {
            return "";
        }
        PushType[] values = PushType.values();
        for (PushType type : values) {
            if (type.getCode().equals(code)) {
                return type.getName();
            }
        }
        return "";
    }
}
