package com.gov.ludeng.system.service;

import com.github.pagehelper.PageInfo;
import com.gov.ludeng.common.base.entity.Pagination;
import com.gov.ludeng.common.base.service.BaseService;
import com.gov.ludeng.system.entity.User;
import com.gov.ludeng.system.vo.UserVO;
import com.gov.ludeng.system.vo.valid.UserValid;

import java.util.List;
import java.util.Map;


public interface UserService extends BaseService<User, Integer> {


    UserVO getUser(String number);

    Map<String,Object> login(String account, String password);

    PageInfo getList(UserVO user, Pagination pagination);

    void add(UserValid valid);

    void update(UserValid valid, Integer userId);

    List<String> getUserList(String area);
}
