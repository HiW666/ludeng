package com.gov.ludeng.common.base.service;


import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gov.ludeng.common.base.entity.Pagination;
import com.gov.ludeng.common.base.mapper.BaseMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.List;

public class BaseServiceImpl<M, ID extends Serializable, BM extends BaseMapper<M>> implements BaseService<M, ID> {

    @Autowired
    protected BM baseMapper;

    @Override
    public <P> PageInfo<P> getPageInfo(Pagination pagination, Class<P> pClass) {
        Page<P> page = PageHelper.startPage(pagination.getPage(), pagination.getRows());
        page.setOrderBy(pagination.getOrderBy());
        if (pagination.getInput() == null) {
            pagination.setInput(new JSONObject());
        }
        P obj = pagination.getInput().toJavaObject(pClass);
        baseMapper.getPageInfo(obj);
        PageInfo<P> pageInfo = new PageInfo<P>(page);
        return pageInfo;
    }

    @Override
    public M selectOne(M entity) {
        return baseMapper.selectOne(entity);
    }

    @Override
    public M selectById(ID id) {
        return baseMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<M> selectList(M entity) {
        return baseMapper.select(entity);
    }

    @Override
    public List<M> selectListAll() {
        return baseMapper.selectAll();
    }

    @Override
    public Long selectCount(M entity) {
        return new Long(baseMapper.selectCount(entity));
    }

    @Override
    public <P> List<P> getAllInfo(P p) {
        return baseMapper.getPageInfo(p);
    }

    @Override
    @Transactional
    public M insert(M entity) {
        baseMapper.insert(entity);
        return entity;
    }


    @Override
    @Transactional
    public M insertSelective(M entity) {
        baseMapper.insertSelective(entity);
        return entity;
    }


    @Override
    @Transactional
    public void deleteById(ID id) {
        baseMapper.deleteByPrimaryKey(id);
    }

    @Override
    @Transactional
    public void updateById(M entity) {
        baseMapper.updateByPrimaryKey(entity);
    }

    @Override
    @Transactional
    public void updateSelectiveById(M entity) {
        baseMapper.updateByPrimaryKeySelective(entity);
    }

    @Override
    public List<M> selectByExample(Object example) {
        return baseMapper.selectByExample(example);
    }

    @Override
    public int selectCountByExample(Object example) {
        return baseMapper.selectCountByExample(example);
    }

}
