package com.gov.ludeng.common.base.exception;

public class BaseException extends RuntimeException {

    private static final long serialVersionUID = 2902281066091712315L;

    protected int errorCode = -1;

    public BaseException(String message) {
        super(message);
    }

    public BaseException(int errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }
}
