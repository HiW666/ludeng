package com.gov.ludeng.JPush.entity;

import java.util.List;
import java.util.Map;

public class PushInfo {

    /**
     * 用于获取消息的key值
     */
    private String key;

    /**
     * 其它扩展数据,少量数据
     */
    private Map<String,String> extras;

    private String message;


    private List<String> pushIds;
    /**
     * 目前只有安卓存在可使用
     */
    private String title;

    /**
     * 用于区分消息主题(不显视)
     */
    private String subject;

    /**
     * 与pushIds 二选一使用,tags存在优先
     */
    private List<String> tags;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Map<String, String> getExtras() {
        return extras;
    }

    public void setExtras(Map<String, String> extras) {
        this.extras = extras;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<String> getPushIds() {
        return pushIds;
    }

    public void setPushIds(List<String> pushIds) {
        this.pushIds = pushIds;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }
}
