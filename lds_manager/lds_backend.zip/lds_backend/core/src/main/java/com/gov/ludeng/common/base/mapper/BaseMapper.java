package com.gov.ludeng.common.base.mapper;


import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface BaseMapper<T> extends Mapper<T> {

    //分页查询，使用分页查询控件
    <P> List<P> getPageInfo(P item);

}
