
package com.gov.ludeng.common.base.controller;

import com.github.pagehelper.PageInfo;
import com.gov.ludeng.common.base.entity.Pagination;
import com.gov.ludeng.common.base.service.BaseService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.Serializable;

import com.gov.ludeng.common.base.entity.JsonResult;
import com.gov.ludeng.common.utils.SpecialDateEditor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

/**
 * 控制基础类，所以controller都应该继承这个类
 */
public abstract class BaseController<Entity, ID extends Serializable> {

    protected final Logger loger = LoggerFactory.getLogger(this.getClass());

    @InitBinder
    protected void init(HttpServletRequest request, ServletRequestDataBinder binder) {
        binder.registerCustomEditor(Date.class, new SpecialDateEditor());
    }


    public abstract Class getPageClassVo();

//    @ResponseBody
//    @RequestMapping(value = "getPageInfo", method = RequestMethod.POST)
//    public JsonResult getPageInfo(@RequestBody Pagination pagination) {
//        JsonResult result = new JsonResult();
//        PageInfo pageInfo = getBaseService().getPageInfo(pagination, getPageClassVo());
//        result.setData(pageInfo);
//        return result;
//    }

    @ResponseBody
    @RequestMapping(value = "getById", method = {RequestMethod.POST, RequestMethod.GET})
    public JsonResult getById(ID id) {
        JsonResult result = new JsonResult();
        result.setData(getBaseService().selectById(id));
        return result;
    }

    /**
     * 新增entityStr
     *
     * @param entityStr EntityStrVO
     * @return json对象
     */
    @ResponseBody
    @RequestMapping(value = "add", method = RequestMethod.POST)
    public JsonResult add(Entity entityStr) {
        JsonResult result = new JsonResult();
        getBaseService().insert(entityStr);
        return result;
    }


    /**
     * 编辑entityStr
     *
     * @param entityStr EntityStrVO
     * @return json对象
     */
    @ResponseBody
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public JsonResult update(Entity entityStr) {
        JsonResult result = new JsonResult();
        getBaseService().updateSelectiveById(entityStr);
        return result;
    }

    /**
     * 删除entityStr
     *
     * @param id entityStrId
     * @return json对象
     */
    @ResponseBody
    @RequestMapping(value = "deleteById", method = RequestMethod.POST)
    public JsonResult deleteById(ID id) {
        JsonResult result = new JsonResult();
        getBaseService().deleteById(id);
        return result;
    }


    public abstract BaseService getBaseService();
}
