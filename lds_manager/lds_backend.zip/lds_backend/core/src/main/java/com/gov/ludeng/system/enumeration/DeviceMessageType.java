package com.gov.ludeng.system.enumeration;

import com.gov.ludeng.common.utils.BeanMapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 故障类型：1、异常跳闸，2、通信断开，
 */
public enum DeviceMessageType {


    BREAK(1, "异常跳闸"), DISCONNECT(2, "通信断开");

    private Integer code;
    private String name;

    DeviceMessageType(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static List<Map<String, Object>> getElements() {
        DeviceMessageType[] values = DeviceMessageType.values();
        List<Map<String, Object>> elements = new ArrayList<Map<String, Object>>(values.length);
        for (DeviceMessageType type : values) {
            try {
                elements.add(BeanMapUtils.toMap(type));
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        }

        return elements;
    }

    public static Integer getCodeByName(String name) {
        if (StringUtils.isEmpty(name)) return null;
        DeviceMessageType[] values = DeviceMessageType.values();
        for (DeviceMessageType type : values) {
            if (type.getName().equals(name)) {
                return type.getCode();
            }
        }
        return null;
    }

    public static String getNameByCode(Integer code) {
        if (code == null) {
            return "";
        }
        DeviceMessageType[] values = DeviceMessageType.values();
        for (DeviceMessageType type : values) {
            if (type.getCode().equals(code)) {
                return type.getName();
            }
        }
        return "";
    }
}
