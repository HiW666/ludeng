package com.gov.ludeng.common.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.text.SimpleDateFormat;

public class JacksonObjectMapper extends ObjectMapper {

	private static final long serialVersionUID = -7602445702870271501L;

	public static final String DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";

	private static JacksonObjectMapper instance;

	private JacksonObjectMapper() {
		setDateFormat(new SimpleDateFormat(DATE_TIME_PATTERN));
		configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	public static JacksonObjectMapper getInstance() {
		if (instance == null) {
			instance = new JacksonObjectMapper();
			instance.setSerializationInclusion(JsonInclude.Include.ALWAYS);
		}
		return instance;
	}

}
