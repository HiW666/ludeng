package com.gov.ludeng.JPush.service;

import cn.jpush.api.JPushClient;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Message;
import cn.jpush.api.push.model.Options;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.AndroidNotification;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;
import com.gov.ludeng.JPush.entity.PushInfo;
import com.gov.ludeng.JPush.entity.PushResultInfo;
import com.gov.ludeng.system.enumeration.PushType;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class JPushServiceImpl implements JPushService {

    private static Logger logger = LoggerFactory.getLogger(JPushServiceImpl.class);

    @Value("${jpush.appkey}")
    private String pushAppKey;

    @Value("${jpush.mastersecret}")
    private String pushMasterSecret;

    @Value("${jpush.isIOSApnsEnv}")
    private boolean isIOSApnsEnv;

    private JPushClient jpushClient;

    private JPushClient getClient() {
        if (jpushClient == null) {
            jpushClient = new JPushClient(pushMasterSecret, pushAppKey);
        }
        return jpushClient;
    }

    public PushResultInfo doPushMessage(String key, PushType pushType, List<String> list) {
        PushInfo pushInfo = new PushInfo();
        pushInfo.setTitle(pushType.getCode() + " : " + key);
        pushInfo.setKey(key);
        pushInfo.setMessage(pushType.getName());
        pushInfo.setSubject(pushType.getCode());
        pushInfo.setPushIds(list);
        return doPush(pushInfo);
    }

    private PushResultInfo doPush(PushInfo info) {
        PushResultInfo pushResult = new PushResultInfo();
        if (info.getKey() == null) {
            pushResult.setStatusCode(500);
            pushResult.setMessage("key不能为空");
            return pushResult;
        }
        if (info.getMessage() == null) {
            pushResult.setStatusCode(500);
            pushResult.setMessage("message不能为空");
            return pushResult;
        }
        JPushClient client = getClient();
        // 平台
        Platform platform = Platform.android_ios();
        Map<String, String> extras = info.getExtras();
        if (extras == null) {
            extras = new HashMap<>();
        }
        extras.put("extra_push_key", info.getKey());
        extras.put("extra_push_subject", info.getSubject());
        // 接收者
        Audience audience = null;
        List<String> pushIdentifiers = info.getPushIds();
        List<String> tags = info.getTags();

        if (tags != null && tags.size() > 0) {
            audience = Audience.tag(tags);
        } else {
            if (pushIdentifiers != null) {
                // 指定接收者
                audience = Audience.alias(pushIdentifiers);
            } else {
                // 全部
                audience = Audience.all();
            }
        }


        Message message = null;
        Notification notification = null;
        {
            // 安卓推送样式
            AndroidNotification androidNotification = AndroidNotification.newBuilder()
                    .setBuilderId(1)
                    .setTitle(StringUtils.isEmpty(info.getTitle()) ? "路灯app" : info.getTitle())
                    .addExtras(extras)
                    .build();

            // ios推送样式
            IosNotification iosNotification = IosNotification.newBuilder()
                    .incrBadge(1)// badge+1
                    .setSound("default")
                    .addExtras(extras)
                    .build();

            notification = Notification.newBuilder()
                    .addPlatformNotification(androidNotification)
                    .addPlatformNotification(iosNotification)
                    // 统一设置推送内容
                    .setAlert(info.getMessage())
                    .build();
        }

        // apns生产环境
        Options options = Options.newBuilder()
                .setApnsProduction(isIOSApnsEnv)
                .build();

        PushPayload payload = PushPayload.newBuilder()
                // 设置接收平台
                .setPlatform(platform)
                // 设置通知样式
                .setNotification(notification)
                // 设置消息
                .setMessage(message)
                // 设置接收对象
                .setAudience(audience)
                .setOptions(options)
                .build();
        try {
            PushResult result = null;
            result = client.sendPush(payload);
            logger.info("push result  {} ", result.toString());

            pushResult.setMsg_id(String.valueOf(result.msg_id));
            pushResult.setSendno(String.valueOf(result.sendno));
            pushResult.setStatusCode(result.statusCode);
            if (result.error != null) {
                pushResult.setMessage(result.error.getMessage());
            }

        } catch (Exception e) {
            pushResult.setStatusCode(500);
            pushResult.setMessage(e.getMessage());
            e.printStackTrace();
            logger.error("push error {}", e.getMessage());
        }
        return pushResult;
    }
}
