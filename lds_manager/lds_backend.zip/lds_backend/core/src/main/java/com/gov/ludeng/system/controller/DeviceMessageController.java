package com.gov.ludeng.system.controller;

import com.gov.ludeng.common.base.entity.JsonResult;
import com.gov.ludeng.common.base.entity.Pagination;
import com.gov.ludeng.system.vo.DeviceMessageVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.gov.ludeng.system.service.DeviceMessageService;

import java.util.List;

@RestController
@RequestMapping("/devMsg")
public class DeviceMessageController {

    @Autowired
    private DeviceMessageService deviceMessageService;

    @ResponseBody
    @RequestMapping(value = "list", method = RequestMethod.POST)
    public JsonResult getPageInfo(DeviceMessageVO deviceMessage, Pagination pagination) {
        JsonResult result = new JsonResult();
        result.setData(deviceMessageService.getList(deviceMessage, pagination));
        return result;
    }


    @ResponseBody
    @RequestMapping(value = "handle", method = RequestMethod.POST)
    public JsonResult handle(String token, @RequestParam List<Integer> msgIds, Integer status, String remark) {
        JsonResult result = new JsonResult();
        String userNumber = token.substring(0, token.indexOf("-"));
        deviceMessageService.handle(msgIds, userNumber, status, remark);
        return result;
    }


}