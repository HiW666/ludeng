package com.gov.ludeng.common.base;

public class Constr {
    public static final String prefix = "query_";
}
