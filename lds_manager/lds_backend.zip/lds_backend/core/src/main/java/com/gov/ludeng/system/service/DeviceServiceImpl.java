package com.gov.ludeng.system.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gov.ludeng.common.base.Constr;
import com.gov.ludeng.common.base.entity.Pagination;
import com.gov.ludeng.common.base.exception.BaseException;
import com.gov.ludeng.common.base.service.BaseServiceImpl;
import com.gov.ludeng.common.utils.BeanMapUtils;
import com.gov.ludeng.common.utils.CommonUtils;
import com.gov.ludeng.common.utils.DateUtil;
import com.gov.ludeng.system.entity.Device;
import com.gov.ludeng.system.enumeration.DeviceMessageType;
import com.gov.ludeng.system.enumeration.DeviceStatus;
import com.gov.ludeng.system.mapper.DeviceMapper;
import com.gov.ludeng.system.vo.DeviceMessageVO;
import com.gov.ludeng.system.vo.DeviceVO;
import com.gov.ludeng.system.vo.valid.DeviceValid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class DeviceServiceImpl extends BaseServiceImpl<Device, Integer, DeviceMapper> implements DeviceService {

    @Autowired
    private DeviceMessageService deviceMessageService;

    @Override
    public PageInfo getList(DeviceVO device, Pagination pagination) {
        Page<DeviceVO> page = PageHelper.startPage(pagination.getPage(), pagination.getRows());
        page.setOrderBy(pagination.getOrderBy());
        baseMapper.getPageInfo(device);
        PageInfo<DeviceVO> pageInfo = new PageInfo<>(page);
        return pageInfo;
    }

    @Override
    public void add(DeviceValid valid) {
        // TODO 判断设备编号重复
        checkDevCode(valid.getCode());

        DeviceVO device = new DeviceVO();
        BeanMapUtils.copyProperties(valid, device);
        device.setNumber(CommonUtils.getRandomKey());
        device.setStatus(DeviceStatus.NORMAL.getCode());
        device.setLastHeartBeatTime(DateUtil.getCurrent());

        device.setCreateTime(DateUtil.getCurrent());
        device.setUpdateTime(DateUtil.getCurrent());

        device.setKeyword(Constr.prefix + device.getCode() + "," + device.getName());
        insert(device);
    }

    @Override
    public void update(DeviceValid valid, Integer devId) {
        Device device = selectById(devId);
        if (device == null) {
            throw new BaseException("设备不存在，请重试");
        }

        Device update = new Device();
        update.setId(device.getId());
        update.setName(valid.getName());
        update.setResetTime(valid.getResetTime());
        update.setUpdateTime(DateUtil.getCurrent());
        update.setKeyword(Constr.prefix + device.getCode() + "," + valid.getName());
        updateSelectiveById(update);
    }

    private void checkDevCode(String code) {
        Device query = new Device();
        query.setCode(code);
        List<Device> list = selectList(query);
        if (list != null && list.size() > 0) {
            throw new BaseException("设备编号已存在，请重试");
        }
    }

    @Override
    public List<DeviceVO> getDisconnectDevice(Date date) {
        return baseMapper.getDisconnectDevice(date);
    }

    @Override
    @Transactional
    public void updateStatusByNumber(String deviceNumber, Integer status) {
        baseMapper.updateStatusByNumber(deviceNumber, status);
    }

    @Override
    @Transactional
    public void upload(String code, Integer state) {
        DeviceVO device = baseMapper.getByDeviceCode(code);
        if (device == null) {
            throw new BaseException("设备代码：" + code + "不存在");
        }
        // TODO 心跳，更新设备最后心跳时间
        Device update = new Device();
        update.setId(device.getId());
        update.setLastHeartBeatTime(DateUtil.getCurrent());

        // TODO 通信断开故障自动处理
        update.setStatus(DeviceStatus.NORMAL.getCode());
        deviceMessageService.updateStatusByDeviceNumber(device.getNumber(), DeviceMessageType.DISCONNECT.getCode());

        switch (state) {
            case 1:
                // TODO 跳匝
                update.setStatus(DeviceStatus.BREAK.getCode());
                // TODO 已有跳匝故障不操作
                List<DeviceMessageVO> list = deviceMessageService.getNoDealMessage(device.getNumber(), DeviceMessageType.BREAK.getCode());
                if (list != null && list.size() == 0) {
                    deviceMessageService.add(device, DeviceMessageType.BREAK);
                }
                break;
            case 2:
                // TODO 恢复
                update.setStatus(DeviceStatus.NORMAL.getCode());
                // TODO 跳匝故障自动处理
                deviceMessageService.updateStatusByDeviceNumber(device.getNumber(), DeviceMessageType.BREAK.getCode());
                break;
            default:
                break;
        }

        updateSelectiveById(update);
    }

    @Override
    public void updateAllResetTime(Integer resetTime) {
        baseMapper.updateAllResetTime(resetTime);
    }
}
