package com.gov.ludeng.system.controller;

import com.gov.ludeng.common.base.entity.*;
import com.gov.ludeng.common.base.exception.BaseException;
import com.gov.ludeng.system.service.DeviceService;
import com.gov.ludeng.system.vo.DeviceVO;
import com.gov.ludeng.system.vo.valid.DeviceValid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/dev")
public class DeviceController {

    @Autowired
    private DeviceService deviceService;

    @ResponseBody
    @RequestMapping(value = "list", method = RequestMethod.POST)
    public JsonResult getPageInfo(DeviceVO device, Pagination pagination) {
        JsonResult result = new JsonResult();
        result.setData(deviceService.getList(device, pagination));
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "add", method = RequestMethod.POST)
    public JsonResult add(@Validated({AddGroup.class}) DeviceValid valid) {
        JsonResult result = new JsonResult();
        deviceService.add(valid);
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public JsonResult update(@Validated({UpdateGroup.class}) DeviceValid valid, Integer devId) {
        if (devId == null) {
            throw new BaseException("设备ID不能为空");
        }
        JsonResult result = new JsonResult();
        deviceService.update(valid, devId);
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "delete", method = RequestMethod.POST)
    public JsonResult delete(Integer devId) {
        if (devId == null) {
            throw new BaseException("设备ID不能为空");
        }
        JsonResult result = new JsonResult();
        deviceService.deleteById(devId);
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "upload", method = RequestMethod.GET)
    public JsonResult upload(@RequestParam String device, @RequestParam Integer state) {
        JsonResult result = new JsonResult();
        deviceService.upload(device, state);
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "updateAllResetTime", method = RequestMethod.POST)
    public JsonResult updateAllResetTime(Integer resetTime) {
        if (resetTime == null) {
            throw new BaseException("复位时间不能为空");
        }
        JsonResult result = new JsonResult();
        deviceService.updateAllResetTime(resetTime);
        return result;
    }
}