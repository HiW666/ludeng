package com.gov.ludeng.system.mapper;

import com.gov.ludeng.common.base.mapper.BaseMapper;
import com.gov.ludeng.system.entity.User;
import com.gov.ludeng.system.vo.UserVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserMapper extends BaseMapper<User> {
    UserVO getUser(@Param("number") String number);

    List<String> getUserList(@Param("area") String area);
}