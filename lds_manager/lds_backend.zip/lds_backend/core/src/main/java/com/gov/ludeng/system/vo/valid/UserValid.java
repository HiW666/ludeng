package com.gov.ludeng.system.vo.valid;

import com.gov.ludeng.common.base.entity.AddGroup;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class UserValid {

    @NotEmpty(groups = {AddGroup.class}, message = "用户账号不能为空")
    private String account;

    @NotEmpty(groups = {AddGroup.class}, message = "用户密码不能为空")
    private String password;

    @NotEmpty(groups = {AddGroup.class}, message = "姓名不能为空")
    private String name;

    @NotNull(groups = {AddGroup.class}, message = "用户角色必选")
    private Integer role;

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }
}
