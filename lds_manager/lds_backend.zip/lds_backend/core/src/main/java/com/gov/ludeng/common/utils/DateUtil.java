package com.gov.ludeng.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

	public static final String DEFAULT_FORMAT_STR = "yyyy-MM-dd HH:mm:ss";

	public final static String SIMPLE_DATE_FORMAT = "yyyy-MM-dd";

	private static final SimpleDateFormat DEFAULT_SDF = new SimpleDateFormat(DEFAULT_FORMAT_STR);

	public static final int SECONDS_PER_MIN = 60;

	public static final int SECONDS_PER_HOUR = 60 * SECONDS_PER_MIN;

	public static final int SECONDS_PER_DAY = 24 * SECONDS_PER_HOUR;

	// 转换===================================================================
	public static Date secondToDate(Integer second) {
		return secondToDate(second == null ? 0 : second);
	}

	public static Date secondToDate(int second) {
		Date date = new Date((long) second * 1000L);
		return date;
	}

	public static int dateToSecond(Date date) {
		return (int) (dateToMills(date) / 1000);
	}

	public static long dateToMills(Date date) {
		if (date == null) {
			return 0;
		}
		return date.getTime();
	}

	// 比较===================================================================
	public static boolean isDifferentYear(Date d1, Date d2) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(d1);

		Calendar c2 = Calendar.getInstance();
		c2.setTime(d2);

		return isDifferentYear(c1, c2);
	}

	public static boolean isDifferentMonth(Date d1, Date d2) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(d1);

		Calendar c2 = Calendar.getInstance();
		c2.setTime(d2);

		if (isDifferentYear(c1, c2)) {
			return true;
		}

		return isDifferentMonth(c1, c2);
	}

	public static boolean isDifferentDay(int d1, int d2) {
		return isDifferentDay(secondToDate(d1), secondToDate(d2));
	}

	public static boolean isDifferentDay(Date d1, Date d2) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(d1);

		Calendar c2 = Calendar.getInstance();
		c2.setTime(d2);

		if (isDifferentYear(c1, c2)) {
			return true;
		}

		if (isDifferentMonth(c1, c2)) {
			return true;
		}

		return isDifferentDay(c1, c2);
	}

	public static boolean isDifferentHour(Date d1, Date d2) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(d1);

		Calendar c2 = Calendar.getInstance();
		c2.setTime(d2);

		if (isDifferentYear(c1, c2)) {
			return true;
		}

		if (isDifferentMonth(c1, c2)) {
			return true;
		}

		if (isDifferentDay(c1, c2)) {
			return true;
		}

		return isDifferentHour(c1, c2);
	}

	public static boolean isDifferentMinute(Date d1, Date d2) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(d1);

		Calendar c2 = Calendar.getInstance();
		c2.setTime(d2);

		if (isDifferentYear(c1, c2)) {
			return true;
		}

		if (isDifferentMonth(c1, c2)) {
			return true;
		}

		if (isDifferentDay(c1, c2)) {
			return true;
		}

		if (isDifferentHour(c1, c2)) {
			return true;
		}

		return isDifferentMinute(c1, c2);
	}

	public static boolean isDifferentYear(Calendar c1, Calendar c2) {
		return c1.get(Calendar.YEAR) != c2.get(Calendar.YEAR);
	}

	public static boolean isDifferentMonth(Calendar c1, Calendar c2) {
		return c1.get(Calendar.MONTH) != c2.get(Calendar.MONTH);
	}

	public static boolean isDifferentDay(Calendar c1, Calendar c2) {
		return c1.get(Calendar.DATE) != c2.get(Calendar.DATE);
	}

	public static boolean isDifferentHour(Calendar c1, Calendar c2) {
		return c1.get(Calendar.HOUR) != c2.get(Calendar.HOUR);
	}

	public static boolean isDifferentMinute(Calendar c1, Calendar c2) {
		return c1.get(Calendar.MINUTE) != c2.get(Calendar.MINUTE);
	}

	// 获取===================================================================
	public static int getCurrentSecond() {
		return (int) (getCurrentMillis() / 1000);
	}

	public static long getCurrentMillis() {
		return System.currentTimeMillis();
	}

	public static Date getCurrent() {
		return new Date();
	}

	public static String getCurrentFormated() {
		return format(getCurrent());
	}

	public static Date getCurrentAfterSeconds(int second) {
		Date date = getCurrent();
		return addSecond(date, second);
	}

	public static Date getFirstDateOfMonth(Date targetDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(targetDate);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		return calendar.getTime();
	}

	public static Date getLastDateOfMonth(Date targetDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(targetDate);
		calendar.add(Calendar.MONTH, 1);
		calendar.set(Calendar.DAY_OF_MONTH, 0);
		return calendar.getTime();
	}

	public static Date getDayStart(Date targetDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(targetDate);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		return calendar.getTime();
	}

	public static Date getDayEnd(Date targetDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(targetDate);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		return calendar.getTime();
	}

	// 计算===================================================================
	public static Date addSecond(Date date, int second) {
		return addMillis(date, second * 1000);
	}

	public static Date addMillis(Date date, long millis) {
		long time = date.getTime() + millis;
		return new Date(time);
	}

	// format==================================================================
	public static String format(long millSecond) {
		return format(new Date(millSecond), DEFAULT_SDF);
	}

	public static String format(int second) {
		return format(second, DEFAULT_FORMAT_STR);
	}

	public static String format(int second, String formatStr) {
		return format(secondToDate(second), formatStr);
	}

	public static String format(Date date) {
		return format(date, DEFAULT_SDF);
	}

	public static String format(Date date, String formatStr) {
		SimpleDateFormat sdf = new SimpleDateFormat(formatStr);
		return format(date, sdf);
	}

	public static String format(Date date, SimpleDateFormat sdf) {
		if (date == null) {
			return "";
		}
		return sdf.format(date);
	}

	// parse==================================================================
	public static Date parse(String dateStr) {
		return parse(dateStr, DEFAULT_FORMAT_STR);
	}

	public static Date parse(String dateStr, String formatStr) {
		SimpleDateFormat sdf = new SimpleDateFormat(formatStr);
		return parse(dateStr, sdf);
	}

	public static Date parse(String dateStr, SimpleDateFormat sdf) {
		Date result = null;
		try {
			result = sdf.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static int parseToInt(String dateStr) {
		int result = 0;
		Date date = parse(dateStr, DEFAULT_FORMAT_STR);
		if (date != null) {
			result = dateToSecond(date);
		}
		return result;
	}

	public static int parseToSimpleInt(String dateStr) {
		int result = 0;
		Date date = parse(dateStr, SIMPLE_DATE_FORMAT);
		if (date != null) {
			result = dateToSecond(date);
		}
		return result;
	}

	public static int parseToInt(String dateStr, String formatStr) {
		int result = 0;
		Date date = parse(dateStr, formatStr);
		if (date != null) {
			result = dateToSecond(date);
		}
		return result;
	}

	public static int parseToInt(String dateStr, SimpleDateFormat sdf) {
		int result = 0;
		Date date = parse(dateStr, sdf);
		if (date != null) {
			result = dateToSecond(date);
		}
		return result;
	}

	public static int getCurrentWeekDay() {
		Calendar now = Calendar.getInstance();
		//一周第一天是否为星期天
		boolean isFirstSunday = (now.getFirstDayOfWeek() == Calendar.SUNDAY);
		//获取周几
		int weekDay = now.get(Calendar.DAY_OF_WEEK);
		//若一周第一天为星期天，则-1
		if(isFirstSunday){
		    weekDay = weekDay - 1;
		    if(weekDay == 0){
		        weekDay = 7;
		    }
		}
		return weekDay;
	}
}
