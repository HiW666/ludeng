package com.gov.ludeng;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import tk.mybatis.spring.annotation.MapperScan;

@SpringBootApplication(scanBasePackages = "com.gov")
@EnableTransactionManagement
@MapperScan(basePackages = { "com.gov.ludeng.system.mapper"}, sqlSessionFactoryRef = "sqlSessionFactory")
public class CoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(CoreApplication.class, args);
    }
}
