package com.gov.ludeng.system.mapper;

import com.gov.ludeng.common.base.mapper.BaseMapper;
import com.gov.ludeng.system.entity.Device;
import com.gov.ludeng.system.vo.DeviceVO;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface DeviceMapper extends BaseMapper<Device> {
    List<DeviceVO> getDisconnectDevice(@Param("date") Date date);

    void updateStatusByNumber(@Param("deviceNumber") String deviceNumber, @Param("status") Integer status);

    DeviceVO getByDeviceCode(@Param("code") String code);

    void updateAllResetTime(@Param("resetTime") Integer resetTime);
}