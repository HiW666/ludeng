package com.gov.ludeng.common.base.entity;

public interface UpdateGroup {
}
