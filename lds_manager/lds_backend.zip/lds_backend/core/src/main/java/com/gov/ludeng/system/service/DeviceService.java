package com.gov.ludeng.system.service;


import com.github.pagehelper.PageInfo;
import com.gov.ludeng.common.base.entity.Pagination;
import com.gov.ludeng.common.base.service.BaseService;
import com.gov.ludeng.system.entity.Device;
import com.gov.ludeng.system.vo.DeviceVO;
import com.gov.ludeng.system.vo.valid.DeviceValid;

import java.util.Date;
import java.util.List;


public interface DeviceService extends BaseService<Device, Integer> {


    PageInfo getList(DeviceVO device, Pagination pagination);

    void add(DeviceValid valid);

    void update(DeviceValid valid, Integer devId);

    List<DeviceVO> getDisconnectDevice(Date date);

    void updateStatusByNumber(String deviceNumber, Integer status);

    void upload(String device, Integer state);

    void updateAllResetTime(Integer resetTime);
}
