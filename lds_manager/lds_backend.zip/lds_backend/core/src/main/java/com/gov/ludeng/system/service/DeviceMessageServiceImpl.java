package com.gov.ludeng.system.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gov.ludeng.JPush.service.JPushService;
import com.gov.ludeng.common.base.Constr;
import com.gov.ludeng.common.base.entity.Pagination;
import com.gov.ludeng.common.base.exception.BaseException;
import com.gov.ludeng.common.base.service.BaseServiceImpl;
import com.gov.ludeng.common.utils.CommonUtils;
import com.gov.ludeng.common.utils.DateUtil;
import com.gov.ludeng.system.entity.DeviceMessage;
import com.gov.ludeng.system.enumeration.DeviceMessageStatus;
import com.gov.ludeng.system.enumeration.DeviceMessageType;
import com.gov.ludeng.system.enumeration.DeviceStatus;
import com.gov.ludeng.system.enumeration.PushType;
import com.gov.ludeng.system.mapper.DeviceMessageMapper;
import com.gov.ludeng.system.vo.DeviceMessageVO;
import com.gov.ludeng.system.vo.DeviceVO;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
public class DeviceMessageServiceImpl extends BaseServiceImpl<DeviceMessage, Integer, DeviceMessageMapper> implements DeviceMessageService {

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private JPushService jPushService;

    @Autowired
    private UserService userService;

    @Override
    public PageInfo getList(DeviceMessageVO deviceMessage, Pagination pagination) {
        Page<DeviceMessageVO> page = PageHelper.startPage(pagination.getPage(), pagination.getRows());
        page.setOrderBy(pagination.getOrderBy());
        baseMapper.getPageInfo(deviceMessage);
        PageInfo<DeviceMessageVO> pageInfo = new PageInfo<>(page);
        return pageInfo;
    }

    @Override
    @Transactional
    public void add(DeviceVO device, DeviceMessageType type) {
        DeviceMessageVO deviceMessage = new DeviceMessageVO();
        deviceMessage.setNumber(CommonUtils.getRandomKey());
        deviceMessage.setType(type.getCode());
        deviceMessage.setStatus(DeviceMessageStatus.UNTREATED.getCode());
        deviceMessage.setPushState(false);

        deviceMessage.setDeviceNumber(device.getNumber());
        deviceMessage.setDeviceCode(device.getCode());
        deviceMessage.setDeviceName(device.getName());
        deviceMessage.setCreateTime(DateUtil.getCurrent());
        deviceMessage.setKeyword(Constr.prefix + device.getCode() + "," + device.getName());

        int resetTime =  30;
        if (device.getResetTime() != null) {
            resetTime = device.getResetTime();
        }
        deviceMessage.setSecondPushTime(DateUtils.addMinutes(deviceMessage.getCreateTime(), resetTime));

        insert(deviceMessage);

        // TODO 更新设备状态
        Integer status = type.equals(DeviceMessageType.DISCONNECT) ? DeviceStatus.DISCONNECT.getCode() : DeviceStatus.BREAK.getCode();
        deviceService.updateStatusByNumber(deviceMessage.getDeviceNumber(), status);

        // TODO 推送
        PushType pushType = type.equals(DeviceMessageType.DISCONNECT) ? PushType.DISCONNECT : PushType.PRE_BREAK;
        List<String> userList = userService.getUserList(null);
        jPushService.doPushMessage(device.getCode(), pushType, userList);
    }

    @Override
    @Transactional
    public void handle(List<Integer> msgIds, String userNumber, Integer status, String remark) {
        if (msgIds == null) {
            throw new BaseException("故障ID不能为空");
        }
        if (status == null) {
            throw new BaseException("处理状态不能为空");
        }
        if (StringUtils.isEmpty(DeviceMessageStatus.getNameByCode(status))) {
            throw new BaseException("处理状态不正确");
        }
        if (msgIds.size() > 0) {
            for (Integer msgId : msgIds) {
                DeviceMessage deviceMessage = selectById(msgId);
                if (deviceMessage != null) {
                    // TODO 跳过状态已处理的
                    if (deviceMessage.getStatus().equals(DeviceMessageStatus.COMPLETE.getCode())) {
                        continue;
                    }
                    // TODO 跳过当前状态与要修改的状态一致的
                    if (deviceMessage.getStatus().equals(status)) {
                        continue;
                    }


                    DeviceMessage update = new DeviceMessage();
                    update.setId(msgId);
                    update.setStatus(status);
                    update.setDealUserNumber(userNumber);
                    update.setDealTime(DateUtil.getCurrent());
                    update.setRemark(remark);
                    updateSelectiveById(update);

                    if (status.equals(DeviceMessageStatus.COMPLETE.getCode())) {
                        // TODO 更新设备状态
                        deviceService.updateStatusByNumber(deviceMessage.getDeviceNumber(), DeviceStatus.NORMAL.getCode());
                    }
                }
            }
        }
    }

    @Transactional
    public void updateStatusByDeviceNumber(String deviceNumber, Integer type) {
        baseMapper.updateStatusByDeviceNumber(deviceNumber, type);
    }

    @Override
    public List<DeviceMessageVO> getNoDealMessage(String deviceNumber, Integer type) {
        return baseMapper.getNoDealMessage(deviceNumber, type);
    }

    @Override
    public List<DeviceMessageVO> getSecondPushList() {
        return baseMapper.getSecondPushList();
    }
}
