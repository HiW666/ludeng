package com.gov.ludeng.JPush.service;

import com.gov.ludeng.JPush.entity.PushResultInfo;
import com.gov.ludeng.system.enumeration.PushType;

import java.util.List;

public interface JPushService {

    PushResultInfo doPushMessage(String key, PushType pushType, List<String> list);
}
