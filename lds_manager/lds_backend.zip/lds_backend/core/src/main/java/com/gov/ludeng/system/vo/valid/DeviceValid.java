package com.gov.ludeng.system.vo.valid;

import com.gov.ludeng.common.base.entity.AddGroup;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class DeviceValid {

    @NotEmpty(groups = {AddGroup.class}, message = "设备编号不能为空")
    private String code;

    @NotEmpty(groups = {AddGroup.class}, message = "设备名称不能为空")
    private String name;

    @NotNull(groups = {AddGroup.class}, message = "设备复位时间不能为空")
    private Integer resetTime;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getResetTime() {
        return resetTime;
    }

    public void setResetTime(Integer resetTime) {
        this.resetTime = resetTime;
    }
}
