package com.gov.ludeng.system.enumeration;

import com.gov.ludeng.common.utils.BeanMapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 故障处理状态：0、未处理，1、处理中，2、已处理，
 */
public enum DeviceMessageStatus {


    UNTREATED(0, "未处理"), DEALING(1, "处理中"), COMPLETE(2, "已处理");

    private Integer code;
    private String name;

    DeviceMessageStatus(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static List<Map<String, Object>> getElements() {
        DeviceMessageStatus[] values = DeviceMessageStatus.values();
        List<Map<String, Object>> elements = new ArrayList<Map<String, Object>>(values.length);
        for (DeviceMessageStatus type : values) {
            try {
                elements.add(BeanMapUtils.toMap(type));
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        }

        return elements;
    }

    public static Integer getCodeByName(String name) {
        if (StringUtils.isEmpty(name)) return null;
        DeviceMessageStatus[] values = DeviceMessageStatus.values();
        for (DeviceMessageStatus type : values) {
            if (type.getName().equals(name)) {
                return type.getCode();
            }
        }
        return null;
    }

    public static String getNameByCode(Integer code) {
        if (code == null) {
            return "";
        }
        DeviceMessageStatus[] values = DeviceMessageStatus.values();
        for (DeviceMessageStatus type : values) {
            if (type.getCode().equals(code)) {
                return type.getName();
            }
        }
        return "";
    }
}
