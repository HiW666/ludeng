package com.gov.ludeng.system.mapper;

import com.gov.ludeng.common.base.mapper.BaseMapper;
import com.gov.ludeng.system.entity.DeviceMessage;
import com.gov.ludeng.system.vo.DeviceMessageVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DeviceMessageMapper extends BaseMapper<DeviceMessage> {
    void updateStatusByDeviceNumber(@Param("deviceNumber") String deviceNumber, @Param("type") Integer type);

    List<DeviceMessageVO> getNoDealMessage(@Param("deviceNumber") String deviceNumber, @Param("type") Integer type);

    List<DeviceMessageVO> getSecondPushList();
}