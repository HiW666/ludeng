package com.gov.ludeng.common.config;


import com.gov.ludeng.common.base.exception.BaseException;
import com.gov.ludeng.common.utils.MD5Util;
import com.gov.ludeng.common.utils.RequestUtil;
import com.gov.ludeng.system.entity.User;
import com.gov.ludeng.system.service.UserService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.List;

/**
 * 访问验证
 */
public class AuthenticationInterceptor extends HandlerInterceptorAdapter {
    private static final Logger logger = LoggerFactory.getLogger(AuthenticationInterceptor.class);

    private String[] ignoreUrl = {"/index"};

    @Autowired
    private UserService userService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String requestUri = request.getRequestURI();
        String contextPath = request.getContextPath();
        String url = requestUri.substring(contextPath.length());
        logger.info("url>>>: " + url);

        String ipAddr = RequestUtil.getIpAddr(request);
        logger.info("IP来自 >>>>>>" + ipAddr + " 请求访问。");

        List<String> l = Arrays.asList(ignoreUrl);
        if (!l.contains(url)) {
            //token、sign验证
            sessionVerification(request, response, handler);

            rightVerification(request, response, handler);
        }

        return true;
    }

    /**
     * 验证签名
     * 1、应用签名appsign = md5(md5(appid + appkey + timestamp))
     * 2、用户签名sign = md5(md5(userid + token + timestamp))
     */
    private void sessionVerification(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String token = request.getParameter("token");
        logger.info("请求token=============" + token);

        if (StringUtils.isEmpty(token)) {
            throw new BaseException(-2, "token不能空，请重试");
        }
        if (!token.contains("-")) {
            throw new BaseException(-2, "token格式不正确");
        }
        String userNumber = token.substring(0, token.indexOf("-"));
        logger.info("userNumber=============" + userNumber);
        User query = new User();
        query.setNumber(userNumber);
        User user = userService.selectOne(query);
        if (user == null) {
            throw new BaseException(-2, "请求用户不存在");
        }
        String tt = user.getToken();
        logger.info("用户token=============" + token);
//        String t_sign = createSign(userNumber, token, timestamp);
        if (!tt.equals(token)) {
            throw new BaseException(-2, "用户登录已过期，请重新登录");
        }

    }


    private void rightVerification(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

    }

    private String createSign(String id, String key, String timestamp) {
        String str = id + key + timestamp;
        return MD5Util.MD5(MD5Util.MD5(str));
    }

}
