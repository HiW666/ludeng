package com.gov.ludeng.system.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gov.ludeng.common.base.entity.Pagination;
import com.gov.ludeng.common.base.exception.BaseException;
import com.gov.ludeng.common.base.service.BaseServiceImpl;
import com.gov.ludeng.common.utils.BeanMapUtils;
import com.gov.ludeng.common.utils.CommonUtils;
import com.gov.ludeng.common.utils.DateUtil;
import com.gov.ludeng.common.utils.MD5Util;
import com.gov.ludeng.system.vo.UserVO;
import com.gov.ludeng.system.vo.valid.UserValid;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import com.gov.ludeng.system.entity.User;
import com.gov.ludeng.system.mapper.UserMapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class UserServiceImpl extends BaseServiceImpl<User, Integer, UserMapper> implements UserService {

    @Override
    public UserVO getUser(String number) {
        UserVO user = baseMapper.getUser(number);
        if (user == null) {
            throw new BaseException("用户不存在");
        }
        List<Integer> l = new ArrayList<>();
        l.add(user.getRole());
        user.setRoles(l);
        return user;
    }

    @Override
    public Map<String, Object> login(String account, String password) {
        Map<String, Object> map = new HashMap<>();
        User query = new User();
        query.setAccount(account);
        User v = selectOne(query);
        if (v == null) {
            throw new BaseException("账号不存在，请联系管理员");
        }

        String md5Password = MD5Util.MD5(password);
        if (!v.getPassword().equals(md5Password)) {
            throw new BaseException("登录密码错误");
        }

        String newToken = v.getNumber() + "-" + CommonUtils.getRandomKey();
        User update = new User();
        update.setId(v.getId());
        update.setToken(newToken);
        update.setUpdateTime(DateUtil.getCurrent());
        updateSelectiveById(update);

        map.put("userNumber", v.getNumber());
        map.put("name", v.getName());
        map.put("token", newToken);
        List<Integer> l = new ArrayList<>();
        l.add(v.getRole());
        map.put("roles", l);
        return map;
    }

    @Override
    public PageInfo getList(UserVO user, Pagination pagination) {
        Page<UserVO> page = PageHelper.startPage(pagination.getPage(), pagination.getRows());
        page.setOrderBy(pagination.getOrderBy());
        baseMapper.getPageInfo(user);
        PageInfo<UserVO> pageInfo = new PageInfo<>(page);
        return pageInfo;
    }

    @Override
    public void add(UserValid valid) {
        // TODO 检查是否存在
        checkUser(valid.getAccount());

        User user = new User();
        BeanMapUtils.copyProperties(valid, user);
        if (StringUtils.isEmpty(user.getName())) {
            user.setName(user.getAccount());
        }
        user.setNumber(CommonUtils.getRandomKey());
        user.setPassword(MD5Util.MD5(valid.getPassword()));

        user.setCreateTime(DateUtil.getCurrent());
//        user.setUpdateTime(DateUtil.getCurrent());

        insert(user);
    }

    @Override
    public void update(UserValid valid, Integer userId) {

        User user = selectById(userId);
        if (user == null) {
            throw new BaseException("用户不存在，请重试");
        }

        User update = new User();
        update.setId(user.getId());
        update.setName(valid.getName());
        update.setRole(valid.getRole());
        if (StringUtils.isNotEmpty(valid.getPassword())) {
            update.setPassword(MD5Util.MD5(valid.getPassword()));
        }
//        update.setUpdateTime(DateUtil.getCurrent());
        updateSelectiveById(update);
    }

    private void checkUser(String account) {
        User query = new User();
        query.setAccount(account);
        List<User> list = selectList(query);
        if (list != null && list.size() > 0) {
            throw new BaseException("用户已存在，请重试");
        }
    }

    @Override
    public List<String> getUserList(String area) {
        return baseMapper.getUserList(area);
    }
}
