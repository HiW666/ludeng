//
//  AppDelegate.h
//  StreetLampsManager
//
//  Created by 冼嘉良 on 2019/9/16.
//  Copyright © 2019 xjl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

