//
//  ErrorListModel.m
//  StreetLampsManager
//
//  Created by 冼嘉良 on 2019/10/9.
//  Copyright © 2019 xjl. All rights reserved.
//

#import "ErrorListModel.h"

@implementation ErrorListModel
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end
