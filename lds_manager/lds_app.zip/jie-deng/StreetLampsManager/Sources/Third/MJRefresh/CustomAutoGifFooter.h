//
//  CustomAutoGifFooter.h
//  CustomGifRefresh
//
//  Created by WXQ on 2018/8/20.
//  Copyright © 2018年 JingBei. All rights reserved.
//

#import "MJRefreshAutoGifFooter.h"

@interface CustomAutoGifFooter : MJRefreshAutoGifFooter

@end
